package com.mapriluzikgmail.monstershot;

/**
 * Created by alfo00 on 2017-06-30.
 */

public class G {

    public static int gem;
    public static int champion;
    public static int kind;  //플레이어 종류

    public static String imgUri;  //이미지의 Uri 패스

    public static boolean isMusic= true;
    public static boolean isSound= true;
    public static boolean isVibrate= true;

}
